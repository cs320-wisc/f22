print("Welcome to the adder program!")

def f(x, y):
    print(f"{x} plus {y} is {x+y}")

f(1, 1)

print("Bye")
